#ifndef _BASE64_H_
#define _BASE64_H_

#include <iostream>
#include <string>
#include <vector>
using namespace std;

/**
 *  @brief these methods convert byte arrays in to base64 codes and are used
 *  in BRIDGES to represent the color arrays as strings. The code is
 *	adapted from external sources detailed below.
 *
 *  base64.cpp and base64.h
 *  Copyright (C) 2004-2008 René Nyffenegger
 *
 *  This source code is provided 'as-is', without any express or implied
 *  warranty. In no event will the author be held liable for any damages
 *  arising from the use of this software.
 *
 *  Permission is granted to anyone to use this software for any purpose,
 *  including commercial applications, and to alter it and redistribute it
 *  freely, subject to the following restrictions:
 *
 *  1. The origin of this source code must not be misrepresented; you must not
 *    claim that you wrote the original source code. If you use this source code
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 *
 *   2. Altered source versions must be plainly marked as such, and must not be
 *      misrepresented as being the original source code.
 *
 *   3. This notice may not be removed or altered from any source distribution.
 *
 *   René Nyffenegger rene.nyffenegger@adp-gmbh.ch
 *
 *   Modified Implementation [from LihO, Dec. 18, 12]
 *	https://stackoverflow.com/questions/180947/base64-decode-snippet-in-c

 */


namespace bridges {
	typedef unsigned char BYTE;


	namespace base64 {

		const string base64_chars =
			"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
			"abcdefghijklmnopqrstuvwxyz"
			"0123456789+/";


		inline bool is_base64(BYTE c) {
			return (isalnum(c) || (c == '+') || (c == '/'));
		}

		string inline encode(BYTE const* buf, unsigned int bufLen) {
			string ret;
			int i = 0;
			int j = 0;
			BYTE char_array_3[3];
			BYTE char_array_4[4];

			while (bufLen--) {
				// 3 chars become 4 chars in base 64 representation
				// hence the char arrays of 3 and 4
				char_array_3[i++] = *(buf++);
				if (i == 3) {
					char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
					char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
					char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
					char_array_4[3] = char_array_3[2] & 0x3f;

					for (i = 0; (i < 4) ; i++)
						ret += base64_chars[char_array_4[i]];
					i = 0;
				}
			}

			// handle any left over bytes, by padding with end of string chars
			if (i) {
				for (j = i; j < 3; j++)
					char_array_3[j] = '\0';

				char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
				char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
				char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
				char_array_4[3] = char_array_3[2] & 0x3f;

				for (j = 0; (j < i + 1); j++)
					ret += base64_chars[char_array_4[j]];

				// not sure what this does!
				while ((i++ < 3))
					ret += '=';
			}

			return ret;
		}

		vector<BYTE> inline decode(string const& encoded_string) {
			size_t in_len = encoded_string.size();
			int i = 0;
			//  int j = 0;
			int in_ = 0;
			BYTE char_array_4[4], char_array_3[3];
			vector<BYTE> ret;

			while (in_len-- && ( encoded_string[in_] != '=') && is_base64(encoded_string[in_])) {
				char_array_4[i++] = encoded_string[in_];
				in_++;
				if (i == 4) {
					for (i = 0; i < 4; i++)
						char_array_4[i] = (BYTE) base64_chars.find(char_array_4[i]);

					char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
					char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
					char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

					for (i = 0; (i < 3); i++)
						ret.push_back(char_array_3[i]);
					i = 0;
				}
			}

			if (i) {
				for (int j = i; j < 4; j++)
					char_array_4[j] = 0;

				for (int j = 0; j < 4; j++)
					char_array_4[j] = (BYTE) base64_chars.find(char_array_4[j]);

				char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
				char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
				char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

				for (int j = 0; (j < i - 1); j++)
					ret.push_back(char_array_3[j]);
			}

			return ret;
		}

	} // end namespace base64
}  // end namespace bridges

#endif
